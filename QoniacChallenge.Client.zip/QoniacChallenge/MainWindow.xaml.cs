﻿using System.Net.Http;
using System.Windows;

namespace QoniacChallenge
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxNumber.Text))
            {
                using (HttpClient client = new HttpClient())
                {
                    var response = await client.GetAsync($"http://localhost:16781/api/CurrenyConverter/Convert?number={textBoxNumber.Text}");
                    response.EnsureSuccessStatusCode();
                    if (response.IsSuccessStatusCode)
                    {
                        string message = await response.Content.ReadAsStringAsync();
                        labelResult.Content = message;
                    }
                }
            }
            else
            {
                labelResult.Content = "Please, enter number";
            }
        }
    }
}
