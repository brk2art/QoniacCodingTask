﻿namespace QoniacChallenge.Api.Models
{
    public enum NumberLimit
    {
        DOLLARS = 999_999_999,
        CENTS = 99
    }
}
