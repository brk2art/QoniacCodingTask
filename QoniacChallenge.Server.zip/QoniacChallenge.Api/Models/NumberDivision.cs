﻿namespace QoniacChallenge.Api.Models
{
    public enum NumberDivision
    {
        MILLION = 1_000_000,
        THOUSAND = 1_000,
        HUNDRED = 100,
        TEN = 10
    }
}
