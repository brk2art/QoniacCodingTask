﻿namespace QoniacChallenge.Api.Models
{
    public class CurrencyNumber
    {
        private int Dollars;
        private int Cents;
        private string number;
        public CurrencyNumber(string Number) 
        { 
            number = Number;
        }

        public int GetDollars()
        {
            return Dollars;
        }

        public int GetCents()
        {
            return Cents;
        }

        public string IsValid()
        {
            decimal convertedNumber;

            if (string.IsNullOrEmpty(number))
            {
                return "Please pass a value";
            }

            if (!decimal.TryParse(number, out convertedNumber))
            {
                return "Please pass a numeric value";
            }

            string[] splittedNumber = number.Split(',');

            //checking validity of dollars
            if (splittedNumber[0].Length > 9) 
            {
                return "Please enter a dollars lower than " + (int)NumberLimit.DOLLARS;
            }
            else
            {
                int dollars = Convert.ToInt32(splittedNumber[0]);
                if(dollars > (int)NumberLimit.DOLLARS)
                {
                    return "Please enter a dollars lower than " + (int)NumberLimit.DOLLARS;
                }
            }

            if(splittedNumber.Length> 1)
            {
                //checking validity of cents
                if (splittedNumber[1].Length > 2)
                {
                    return "Please enter a cents lower than " + (int)NumberLimit.CENTS;
                }
                else
                {
                    int cents = Convert.ToInt32(splittedNumber[1]);
                    if (cents > (int)NumberLimit.CENTS)
                    {
                        return "Please enter a cents lower than " + (int)NumberLimit.CENTS;
                    }
                }
            }

            return "";
        }

        public void ConvertToCurrency()
        {
            if (number.Contains(','))
            {
                string[] splittedNumber = number.Split(',');
                Dollars = Convert.ToInt32(splittedNumber[0]);
                Cents = Convert.ToInt32(splittedNumber[1]);
            }
            else
            {
                Dollars = Convert.ToInt32(number);
                Cents = 0;
            }
        }
    }
}
