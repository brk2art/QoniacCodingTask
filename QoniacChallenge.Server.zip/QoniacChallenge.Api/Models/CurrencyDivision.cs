﻿namespace QoniacChallenge.Api.Models
{
    public enum CurrencyDivision
    {
        Dollar,
        Cent
    }
}
