﻿using Microsoft.AspNetCore.Mvc;
using QoniacChallenge.Api.Services;

namespace QoniacChallenge.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CurrenyConverterController : ControllerBase
    {
        private ICurrencyConverterService _currencyConverterService;

        public CurrenyConverterController(ICurrencyConverterService currencyConverterService)
        {
            _currencyConverterService = currencyConverterService;
        }


        [HttpGet("Convert")]
        public ActionResult Convert(string number)
        {
            return Ok(_currencyConverterService.ConvertToWord(number));
        }
    }
}
