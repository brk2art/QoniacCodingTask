﻿namespace QoniacChallenge.Api.Services
{
    public interface ICurrencyConverterService
    {
        string ConvertToWord(string number);
    }
}
