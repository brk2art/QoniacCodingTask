﻿using QoniacChallenge.Api.Models;

namespace QoniacChallenge.Api.Services
{
    public class CurrencyConverterService : ICurrencyConverterService
    {
        public string ConvertToWord(string number)
        {
            CurrencyNumber currencyNumber = new CurrencyNumber(number);

            var validationMessage = currencyNumber.IsValid();
            if (!string.IsNullOrEmpty(validationMessage))
            {
                return validationMessage;
            }
            else
            {
                currencyNumber.ConvertToCurrency();
            }

            var result = GetDollarPart(currencyNumber.GetDollars());
                
            var centPart = GetCentPart(currencyNumber.GetCents());

            if (!string.IsNullOrEmpty(centPart))
            {
                result += " and " + centPart;
            }

            return result;
        }

        private string GetDollarPart(int dollars)
        {
            string result = CheckMillion(dollars);

            if (!string.IsNullOrEmpty(result))
            {
                result += GetCurrency(CurrencyDivision.Dollar, dollars);
            }

            return result;
        }

        private string GetCentPart(int cents)
        {
            string result = CheckTen(cents);

            if (!string.IsNullOrEmpty(result) && cents != 0)
            {
                result += GetCurrency(CurrencyDivision.Cent, cents);
            }
            else
            {
                result = "";
            }

            return result;
        }

        private string GetCurrency(CurrencyDivision currencyDivision, int value)
        {
            var result = " dollar";

            if(currencyDivision == CurrencyDivision.Cent)
            {
                result = " cent";
            }

            if(value != 1)
            {
                result += "s ";
            }

            return result;
        }

        private string CheckMillion(int number)
        {
            var result = "";
            int millionNumber = number / (int)NumberDivision.MILLION;
            int thousandNumber = number % (int)NumberDivision.MILLION;

            if (millionNumber != 0)
            {
                result = CheckHundred(millionNumber) + " million ";

                if (thousandNumber == 0)
                    return result;
            }

            result += CheckThousand(thousandNumber);

            return result;
        }

        private string CheckThousand(int number)
        {
            var result = "";
            int thousandNumber = number / (int)NumberDivision.THOUSAND;

            if (thousandNumber != 0)
            {
                result = CheckHundred(thousandNumber) + " thousand ";
            }

            result += CheckHundred(number % (int)NumberDivision.THOUSAND);

            return result;
        }

        private string CheckHundred(int number)
        {
            var result = "";
            int hundredNumber = number / (int)NumberDivision.HUNDRED;

            if (hundredNumber != 0)
            {
                result = CheckOne(hundredNumber) + " hundred ";
            }

            result += CheckTen(number % (int)NumberDivision.HUNDRED);

            return result;
        }

        private string CheckTen(int number)
        {
            var result = "";

            if(number < 10)
            {
                result = CheckOne(number);
            }
            else if(number < 20)
            {
                switch (number)
                {
                    case 10:
                        result = "ten";
                        break;
                    case 11:
                        result = "eleven";
                        break;
                    case 12:
                        result = "twelve";
                        break;
                    case 13:
                        result = "thirteen";
                        break;
                    case 14:
                        result = "fourteen";
                        break;
                    case 15:
                        result = "fifteen";
                        break;
                    case 16:
                        result = "sixteen";
                        break;
                    case 17:
                        result = "seventeen";
                        break;
                    case 18:
                        result = "eighteen";
                        break;
                    case 19:
                        result = "nineteen";
                        break;
                }
            }
            else
            {
                int tenNumber = number / (int)NumberDivision.TEN;

                switch (tenNumber)
                {
                    case 2:
                        result = "twenty";
                        break;
                    case 3:
                        result = "thirty";
                        break;
                    case 4:
                        result = "fourty";
                        break;
                    case 5:
                        result = "fifty";
                        break;
                    case 6:
                        result = "sixty";
                        break;
                    case 7:
                        result = "seventy";
                        break;
                    case 8:
                        result = "eighty";
                        break;
                    case 9:
                        result = "ninety";
                        break;
                }

                int oneNumber = number % 10;
                if(oneNumber != 0)
                {
                    result += " " + CheckOne(number % 10);
                }
            }

            return result;
        }

        private string CheckOne(int number)
        {
            string result = "";

            switch (number)
            {
                case 0:
                    result = "zero";
                    break;
                case 1:
                    result = "one";
                    break;
                case 2:
                    result = "two";
                    break;
                case 3:
                    result = "three";
                    break;
                case 4:
                    result = "four";
                    break;
                case 5:
                    result = "five";
                    break;
                case 6:
                    result = "six";
                    break;
                case 7:
                    result = "seven";
                    break;
                case 8:
                    result = "eight";
                    break;
                case 9:
                    result = "nine";
                    break;
            }
            return result;
        }
    }
}
